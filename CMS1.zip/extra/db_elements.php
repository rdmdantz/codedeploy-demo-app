<?php 
 	//if(isset($_POST['submit']))
 		print_r($_POST);
?>