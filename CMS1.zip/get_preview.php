<?php 
include 'db_elements.php';

?>